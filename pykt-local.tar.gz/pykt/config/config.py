que_type_models = ["iekt","qdkt","qikt","lpkt", "rkt", "promptkt"]

qikt_ab_models = ["qikt_ab_a+b+c","qikt_ab_a+b+c+irt","qikt_ab_a+b+irt","qikt_ab_a+c+irt","qikt_ab_a+irt","qikt_ab_b+irt"]

que_type_models += qikt_ab_models